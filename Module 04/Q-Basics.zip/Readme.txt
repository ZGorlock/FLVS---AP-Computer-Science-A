Q-Basics demo program INSTALL notes:

QB64: 

QB64 can be used to run all chapters except 15! Compile "Q-Basics.BAS" first and 
chapters will be compiled in the QB64 folder as used. The program will create
shortcuts for the folder and desktop on first run. If the files are moved, new
shortcuts will be created there. Do not delete Shortcut.VBS!

Quick Basic 4,5:

You must unzip the contents to a Qbasic folder with all of the Qbasic libraries and exe files!
DO NOT UNZIP to a folder without all of the Qbasic files already installed.
The files included in this download need to be in a folder that has Qbasic!

To get a copy of Qbasic4.5 go to qbasicstation.com and look for QB45.ZIP in Member Files - Utilities
If QB.EXE is in another folder, the program will not find the files needed!

64 BIT COMPUTERS: This program will not run fullscreen on 64 bit machines. 
You can use DOSBOX to use it however.


USING THE PROGRAM

Use the Q-BASICS.BAT file to run the program! It will take you to the main menu and includes the 
Library. DON'T RUN the modules when using it for the first time! Chapter 15 requires the Library! 

The files included:

Many of the files are BSAVEd image files. Don't remove or alter them.

Good Luck with your QB programming!

Ted Weissgerber         

burger2227@gmail.com


