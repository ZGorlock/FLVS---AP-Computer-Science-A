/**
 * Contains an interface for Processing Homework assignments
 * 
 * @author Zachary Gill
 * @version 04-19-2013
 */
public interface Processing
{
    public abstract void doReading();
}
